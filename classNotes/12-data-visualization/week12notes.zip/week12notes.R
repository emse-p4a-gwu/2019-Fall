library(tidyverse)

birds <- read_csv(file.path('data', 'wildlife_impacts.csv'))
bears <- read_csv(file.path('data', 'bear_killings.csv'))
